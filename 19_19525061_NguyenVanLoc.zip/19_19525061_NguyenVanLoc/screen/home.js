import { StatusBar } from "expo-status-bar";
import { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  FlatList,
  TextInput,
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import listData from "../data/store";
var listOrder = [];

export default function ScreenHome({ navigation }) {
  const [clickBtn1, setClickBtn1] = useState(true);
  const [clickBtn2, setClickBtn2] = useState(false);
  const [clickBtn3, setClickBtn3] = useState(false);
  const [clickBtn4, setClickBtn4] = useState(false);
  const [clickBtn5, setClickBtn5] = useState(false);
  const [data, setData] = useState([]);

  const handelFilterData = (type) => {
    if (type === 3) {
      setData(listData);
    } else {
      setData(listData.filter((x) => x.type === type));
    }
  };

  const renderItem = ({ item }) => {
    return (
      <View
        style={{
          backgroundColor: "#ccffeb",
          width: "45%",
          alignItems: "center",
          marginTop: 20,
          padding: 20,
          borderRadius: 20,
        }}
      >
        <Image source={item.image} style={{ width: 100, height: 100 }}></Image>
        <View
          style={{
            flexDirection: "row",
            width: "99%",
            justifyContent: "space-between",
            marginTop: 20,
          }}
        >
          <Text style={{ color: "black", fontSize: 15 }}>{item.name}</Text>
          <Text style={{ color: "black", fontSize: 16 }}>$ {item.price}</Text>
        </View>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "flex-end",
            width: "100%",
            height: 30,
            marginTop: 10,
          }}
        >
          <TouchableOpacity
            style={{
              position: "absolute",
              right: -20,
              backgroundColor: "#ff9900",
              width: 60,
              height: 50,
              borderBottomRightRadius: 20,
              borderTopLeftRadius: 20,
              justifyContent: "center",
              alignItems: "center",
            }}
            onPress={() => {
              handelOrder(item);
              navigation.navigate("ScreenCheckout", { listOrder: listOrder });
            }}
          >
            <Icon name="add-circle-outline" size={30} color="black"></Icon>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const handelOrder = (item) => {
    let flag = false;
    listOrder.forEach((x) => {
      if (x.id === item.id) {
        x.total = x.total + 1;
        flag = true;
      }
    });
    if (!flag) {
      listOrder.push({ ...item, total: 1 });
    }
    console.log(listOrder);
  };

  useEffect(() => {
    handelFilterData(1);
  }, []);

  return (
    <View style={styles.container}>
      <View
        style={{
          justifyContent: "space-around",
          flexDirection: "row",
          alignItems: "flex-end",
          padding: 10,
          width: "100%",
          height: 70,
          backgroundColor: "#fff",
        }}
      >
        <Icon style={{ marginRight: 10 }} name="menu" size={50} color="black" />
        <Image
          source="/assets/avt.jpeg"
          style={{
            width: 50,
            height: 200,
            borderRadius: 10,
            marginRight: 160,
          }}
        ></Image>
      </View>
      <View
        style={{
          width: "100%",
          height: "100%",
          alignItems: "center",
        }}
      >
        <Text
          style={{
            fontSize: 20,
            color: "#ff9900",
            fontWeight: "bold",
            marginRight: 150,
          }}
        >
          Eat Nutritious Food {"\n"} and Stay heathy
        </Text>

        <View style={{ position: "relative", width: "90%" }}>
          <Image
            style={{
              position: "absolute",
              left: 5,
              top: 5,
              width: 40,
              height: 40,
            }}
            source={{
              uri: "https://f50-zpg-r.zdn.vn/3376817211445233761/b41304b1067ec020996f.jpg",
            }}
          />
          <TextInput
            style={{
              padding: 15,
              paddingLeft: 50,
              backgroundColor: "gray",
              borderRadius: 10,
              color: "#5d5c5c",
              fontSize: "17px",
            }}
            placeholder="Search here"
          />
          <Image
            style={{
              position: "absolute",
              right: 5,
              top: 5,
              width: 40,
              height: 40,
            }}
            source={{
              uri: "https://f47-zpg-r.zdn.vn/734550350446216167/ae10f6a0c46f02315b7e.jpg",
            }}
          />
        </View>

        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            width: "90%",
            marginTop: 20,
          }}
        >
          <TouchableOpacity
            style={{
              backgroundColor: clickBtn1 ? "" : "gray",
              padding: 10,
            }}
            onPress={() => {
              setClickBtn1(true);
              setClickBtn2(false);
              setClickBtn3(false);
              setClickBtn4(false);
              setClickBtn5(false);
              handelFilterData(3);
            }}
          >
            <Text style={{ fontWeight: "bold", fontSize: 15 }}>Fruits</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              backgroundColor: clickBtn2 ? "" : "gray",
              padding: 10,
            }}
            onPress={() => {
              setClickBtn1(false);
              setClickBtn2(true);
              setClickBtn3(false);
              setClickBtn4(false);
              setClickBtn5(false);
              handelFilterData(1);
            }}
          >
            <Text style={{ fontWeight: "bold", fontSize: 15 }}>Vegetable</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              backgroundColor: clickBtn3 ? "" : "gray",
              padding: 10,
            }}
            onPress={() => {
              setClickBtn1(false);
              setClickBtn2(false);
              setClickBtn3(true);
              setClickBtn4(false);
              setClickBtn5(false);
              handelFilterData(2);
            }}
          >
            <Text style={{ fontWeight: "bold", fontSize: 15 }}>Meet</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              backgroundColor: clickBtn4 ? "" : "gray",
              padding: 10,
            }}
            onPress={() => {
              setClickBtn1(false);
              setClickBtn2(false);
              setClickBtn3(false);
              setClickBtn4(true);
              setClickBtn5(false);
              handelFilterData(2);
            }}
          >
            <Text style={{ fontWeight: "bold", fontSize: 15 }}>Bokery</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              backgroundColor: clickBtn5 ? "" : "gray",
              padding: 10,
            }}
            onPress={() => {
              setClickBtn1(false);
              setClickBtn2(false);
              setClickBtn3(false);
              setClickBtn4(false);
              setClickBtn5(true);
              handelFilterData(2);
            }}
          >
            <Text style={{ fontWeight: "bold", fontSize: 15 }}>Rice</Text>
          </TouchableOpacity>
        </View>
        <View style={{ width: "95%", height: 500 }}>
          <FlatList
            columnWrapperStyle={{ flex: 1, justifyContent: "space-around" }}
            data={data}
            renderItem={renderItem}
            numColumns={2}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "flex-start",
  },
});
