import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, TouchableOpacity, View, Image } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
export default function ScreenIndex({ navigation }) {
  // const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Image style={styles.img} source={require("../assets/index.jpeg")} />
      <Text style={styles.title}>Fresh & Juicy</Text>
      <Text style={styles.text}>
        Get the fresh and juicy fruits at your doorstep
      </Text>
      <TouchableOpacity
        style={styles.btn}
        onPress={() => navigation.navigate("ScreenHome")}
      >
        <Text style={styles.txtbtn}>Get Started</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 40,
    color: "#000",
    paddingHorizontal: 30,
    textAlign: "center",
    fontStyle: "bold",
    marginTop: 100,
  },
  text: {
    fontSize: 18,
    color: "#000",
    textAlign: "center",
    paddingHorizontal: 30,
    marginVertical: 10,
  },
  btn: {
    marginTop: 100,
    backgroundColor: "#ff9900",
    borderRadius: 20,
    width: "80%",
  },
  txtbtn: {
    textAlign: "center",
    padding: 10,
    fontSize: 15,
    color: "#fff",
  },
  img: {
    height: "50%",
    width: "100%",
    borderBottomStartRadius: 150,
    borderBottomEndRadius: 150,
  },
});
