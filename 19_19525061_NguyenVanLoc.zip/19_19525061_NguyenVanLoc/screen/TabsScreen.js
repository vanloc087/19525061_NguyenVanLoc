import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import Ionicons from "react-native-vector-icons/Ionicons";
import ScreenIndex from "/screen/index";
import ScreenHome from "/screen/home";

const Tab = createBottomTabNavigator();

function TabsScreen({ navigation }) {
  return (
    <>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === "Menu") {
              iconName = focused ? "home" : "home-outline";
            } else if (route.name === "Search") {
              iconName = focused ? "search" : "search-outline";
            } else if (route.name === "Heart") {
              iconName = focused ? "heart" : "heart-outline";
            } else if (route.name === "Account") {
              iconName = focused
                ? "notifications-sharp"
                : "notifications-outline";
            } else if (route.name === "Account") {
              iconName = focused ? "person" : "person-outline";
            }

            // You can return any component that you like here!
            return <Ionicons name={iconName} size={size} color={color} />;
          },

          tabBarActiveTintColor: "#808000",
          tabBarInactiveTintColor: "gray",
          tabBarHideOnKeyboard: true,
          tabBarStyle: {
            height: 80,

            paddingTop: 0,
            backgroundColor: "#000",
            borderTopWidth: 0,
          },
        })}
        tabBarOptions={{
          activeBackgroundColor: "#000",
          inactiveBackgroundColor: "#000",
          style: {
            backgroundColor: "#CE4418",
            paddingBottom: 3,
          },
        }}
      >
        <Tab.Screen
          name="Menu"
          component={ScreenHome}
          options={{ headerShown: false, tabBarVisible: false }}
        />
        <Tab.Screen
          name="Heart"
          component={ScreenIndex}
          options={{ headerShown: false, tabBarVisible: false }}
        />
        <Tab.Screen
          name="Search"
          component={ScreenIndex}
          options={{ headerShown: false, tabBarVisible: false }}
        />
        <Tab.Screen
          name="Account"
          component={ScreenIndex}
          options={{ headerShown: false, tabBarVisible: false }}
        />
      </Tab.Navigator>
    </>
  );
}

export default TabsScreen;
