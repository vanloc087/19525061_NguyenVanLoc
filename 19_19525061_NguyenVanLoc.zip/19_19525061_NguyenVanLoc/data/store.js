var listData = [
  {
    id: 1,
    name: "Dâu",
    price: 65,
    image: require("../assets/dau.png"),
    type: 1,
  },
  {
    id: 2,
    name: "Dưa Hấu",
    price: 65,
    image: require("../assets/duahau.jpeg"),
    type: 1,
  },
  {
    id: 3,
    name: "Kiwi",
    price: 65,
    image: require("../assets/kiwi.jpeg"),
    type: 1,
  },
  {
    id: 4,
    name: "Xoai",
    price: 65,
    image: require("../assets/xoai.jpeg"),
    type: 1,
  },
  {
    id: 5,
    name: "Cam",
    price: 35,
    image: require("../assets/cam.jpeg"),
    type: 1,
  },
];

module.exports = listData;
